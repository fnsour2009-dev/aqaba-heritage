# Aqaba: Beyond the Red Sea

A free heritage guide to the Islamic history of Aqaba, Jordan: the early Islamic city of Ayla, Aqaba Castle, the pilgrims' road and nearby sites.

An IB CAS project by Fahad and Saif. Photographs © Fahad & Saif.

Live site: https://fnsour2009-dev.github.io/aqaba-heritage/
